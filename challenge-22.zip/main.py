
# import modules
from tkinter import *
import sports
from tkinter import messagebox 

def cricket_info():

    try:
        match = sports.get_match(sports.CRICKET, e1.get() , e2.get())
        date.set(match.match_date)
        time.set(match.match_time)
        league.set(match.league)
        team1.set(match.home_team)
        team2.set(match.away_team)
        team1_score.set(match.away_score)
        team2_score.set(match.home_score)
        link.set(match.match_link)
    except:
        messagebox.showerror("showerror", "No match found") 
# object of tkinter
# and background set for light grey
master = Tk()
master.configure(bg='light grey')

# Variable Classes in tkinter
date = StringVar();
time = StringVar();
league = StringVar();
team1 = StringVar();
team2 = StringVar();
team1_score = StringVar();
team2_score = StringVar();
link = StringVar();# object of tkinter
# and background set for light grey
master = Tk()
master.configure(bg='light grey')

# Variable Classes in tkinter
date = StringVar();
time = StringVar();
league = StringVar();
team1 = StringVar();
team2 = StringVar();
team1_score = StringVar();
team2_score = StringVar();
link = StringVar();